<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Comment extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Comment_model');
    }

    public function add($post_id) {
        if ($this->input->post()) {
            $data = [
                'post_id' => $post_id,
                'user_id' => $this->session->userdata('user_id'),
                'comment' => $this->input->post('comment'),
                'created_at' => date('Y-m-d H:i:s')
            ];
            $this->Comment_model->add_comment($data);
            redirect('blog/index/' . $post_id);
        } else {
            $data['post_id'] = $post_id;
            $this->load->view('comment_form', $data);
        }
    }

    public function get_comments($post_id) {
        $comments = $this->Comment_model->get_comments($post_id);
        echo json_encode($comments);
    }

    public function delete($id) {
        $this->Comment_model->delete_comment($id);
        redirect('blog/index');
    }
}   
?>
