<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Post</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
            
        }
        h1 {
            text-align: center;
            color: #333; 
            margin-bottom: 20px;
            font-size: 2.5em; 
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff; 
            border-radius: 12px; 
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); 
            padding: 30px;
            transition: transform 0.3s ease; 
            margin-top: 30px;
        }
        .container:hover {
            transform: scale(1.01); 
        }
        label {
            display: block;
            margin-bottom: 8px;
            color: #555; 
            font-weight: 600;
        }
        input[type="text"],
        textarea,
        select {
            width: 100%;
            padding: 12px; 
            margin-bottom: 20px;
            border: 1px solid #ccc; 
            border-radius: 8px; 
            box-sizing: border-box;
            font-size: 1em; 
            transition: border-color 0.3s, box-shadow 0.3s; 
        }
        input[type="text"]:focus,
        textarea:focus,
        select:focus {
            border-color: #007bff; 
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5); 
            outline: none; 
        }
        button {
            background-color: #28a745; 
            color: white;
            padding: 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            font-size: 1.1em; 
            font-weight: bold; 
            transition: background-color 0.3s, transform 0.2s;
        }
        button:hover {
            background-color: #218838; 
            transform: translateY(-2px); 
        }
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
        .back-link a {
            color: #007bff;
            text-decoration: none;
            font-weight: bold; 
            transition: color 0.3s ease; 
        }
        .back-link a:hover {
            color: #0056b3; 
        }
    </style>
</head>
<body>
<?php include 'application/views/common/navbar.php'; ?>
    <div class="container">
        <h1>Edit Post</h1>
        <form method="post">
            <label for="title">Title:</label>
            <input type="text" name="title" value="<?= $post->title ?>" required>
            <label for="body">Content:</label>
            <textarea name="body" required><?= $post->body ?></textarea>
            <label for="category_id">Category:</label>
            <select name="category_id" required>
                <?php foreach ($categories as $category): ?>
                    <option value="<?= $category->id ?>" <?= $category->id == $post->category_id ? 'selected' : '' ?>><?= $category->name ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Update Post</button>
        </form>
        <div class="back-link">
            <p><a href="<?= site_url('admin/manage_posts') ?>">Back to Posts</a></p>
        </div>
    </div>
</body>
</html>
