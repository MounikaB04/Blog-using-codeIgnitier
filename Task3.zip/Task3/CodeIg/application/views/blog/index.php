<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Posts</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #ffe6cc;
            margin: 0;
            padding: 0;
        }
        nav {
            background-color: #333;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }
        .logout {
            color: red;
            margin-left: auto;
        }
        .logout:hover {
            color: white;
        }
        .container {
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
            font-size: 2.5em;
        }
        h2 {
            color: black;
            margin-top: 30px;
            font-size: 2em;
            padding-bottom: 10px;
        }
        ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }
        li {
            background: white;
            margin: 10px 0;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }
        li:hover {
            transform: translateY(-5px);
        }
        a {
            text-decoration: none;
            color: #007bff;
            transition: color 0.3s;
            font-weight: bold;
        }
        a:hover {
            color: #0056b3;
        }
        .create-post {
            display: block;
            margin: 20px auto;
            padding: 15px 20px;
            background-color: green;
            color: white;
            text-align: center;
            border-radius: 8px;
            width: 220px;
            font-size: 1.1em;
            transition: background-color 0.3s, transform 0.2s;
        }
        .create-post:hover {
            background-color: red;
            color: black;
            transform: translateY(-3px);
        }
        .filter-category {
            margin: 20px 0;
            text-align: center;
        }
        .filter-category select {
            padding: 10px;
            font-size: 1em;
            border-radius: 5px;
            border: 1px solid #ccc;
            outline: none;
            transition: border-color 0.3s;
        }
        .filter-category select:hover {
            border-color: #007bff;
        }
        .filter-category select:focus {
            border-color: #0056b3;
        }
        .welcome-message {
            text-align: left;
            font-size: 50px;
            color: #993300;
            margin-bottom: 0px;
        }
        .comment-section {
            margin-top: 20px;
            padding-top: 10px;
            border-top: 1px solid #ccc;
        }
        .comment-section h3 {
            font-size: 1.2em;
            margin-bottom: 10px;
        }
        .comment-section div {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <nav>
        <a class="logout" href="<?= site_url('auth/logout') ?>">Logout</a>
    </nav>
    <div class="container">
        <div class="welcome-message">
            <?php if ($this->session->userdata('username')): ?>
                Welcome, <?= htmlspecialchars($this->session->userdata('username')) ?>
            <?php endif; ?>
        </div>
        <h1>Blog Posts</h1>
        <hr>
        <div class="filter-category">
            <h2>Filter by Category</h2>
            <form action="<?= site_url('blog/index') ?>" method="GET">
                <select name="category_id" onchange="this.form.submit()">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= $category->id ?>" <?= isset($_GET['category_id']) && $_GET['category_id'] == $category->id ? 'selected' : '' ?>>
                            <?= htmlspecialchars($category->name) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>
        <h2>Posts</h2>
        <ul>
            <?php if (!empty($posts)): ?>
                <?php foreach ($posts as $post): ?>
                    <li>
                        <span style="font-size: 1.5em; font-weight: bold;"><?= htmlspecialchars($post->title) ?></span>
                        <p style="margin-top: 10px;"><?= nl2br(htmlspecialchars($post->body)) ?></p>
                        <a href="<?= site_url('comment/add/' . $post->id) ?>" class="btn btn-secondary">Add Comment</a>
                        <div class="comment-section">
                            <h3>Comments</h3>
                            <?php foreach ($post->comments as $comment): ?>
                                <div>
                                    <p><?= htmlspecialchars($comment['comment']) ?></p>
                                    <small>Posted by User ID: <?= $comment['user_id'] ?> on <?= $comment['created_at'] ?></small>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li>No posts available in this category.</li>
            <?php endif; ?>
        </ul>
        <a class="create-post" href="<?= site_url('admin/create_post') ?>">Create New Post</a>
    </div>
</body>
</html>
