<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Comment_model extends CI_Model {
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function add_comment($data) {
        return $this->db->insert('comments', $data);
    }

    public function get_comments($post_id= 0) {
        if($post_id !=0){
            $this->db->where('post_id', $post_id);
        }
        
        return $this->db->get('comments')->result_array();
    }

    public function delete_comment($id) {
        return $this->db->delete('comments', array('id' => $id));
    }
}
?>

